package com.example.freshprox.search;

import androidx.fragment.app.Fragment;

public class ListFragment extends Fragment {
}
