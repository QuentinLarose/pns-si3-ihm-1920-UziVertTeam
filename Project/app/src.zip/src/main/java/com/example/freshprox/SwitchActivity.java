package com.example.freshprox;

public interface SwitchActivity {
    void onClickSwitch(Class<?> cls);
}
