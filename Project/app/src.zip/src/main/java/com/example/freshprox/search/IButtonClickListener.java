package com.example.freshprox.search;

import android.view.View;

public interface IButtonClickListener {
    void onButtonMapClicked(View button);
}
